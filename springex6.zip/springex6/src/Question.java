import java.util.Iterator;  
import java.util.Map;  
import java.util.Set;  
import java.util.Map.Entry;  

public class Question {  
	private int id;  
	private String name; 
	private String bank;
	private String dept;
	private Map<Answer,User> answers;  
	 

	public Question() {}  
	public Question(int id, String name, String bank, String dept, Map<Answer, User> answers) {  
		super();  
		this.id = id;  
		this.name = name; 
		this.bank=bank;
		this.dept=dept;
		this.answers=answers;
	}  


	public void displayInfo()
	{  
		System.out.println("Customer details"); 
		System.out.println("\nCustomer id:"+id);  
		System.out.println("Customer name:"+name);  
		System.out.println("Bank:"+bank);  
		System.out.println("Dept:"+dept); 
		
		Set<Entry<Answer, User>> set=answers.entrySet();  
		Iterator<Entry<Answer, User>> itr=set.iterator();  
		while(itr.hasNext())
		{  
			Entry<Answer, User> entry=itr.next();  
			Answer ans=entry.getKey();  
			User user=entry.getValue();  
			System.out.println("\n\nBank details:");  
			System.out.println(ans);  
			System.out.println("\n\nDepartment:");  
			System.out.println(user);  
		} 
		
	}  
}  