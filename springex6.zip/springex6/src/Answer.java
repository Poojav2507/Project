import java.util.Date;  
  
public class Answer {  
private int accno;  
private String branch;  
private int balance;  
public Answer() {}  
public Answer(int accno, String branch, int balance) {  
    super();  
    this.accno = accno;  
    this.branch=branch;  
    this.balance=balance;  
}  
  
public String toString(){  
    return "\nAccno:"+accno+"\nBranch:"+branch+"\nbalance:"+balance;  
	
}  
}  